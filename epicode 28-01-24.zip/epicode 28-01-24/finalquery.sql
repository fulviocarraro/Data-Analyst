CREATE DATABASE TOYS

USE TOYS;

/* A seguire, la creazione delle tabelle e la stesura del loro contenuto. Sono presenti errori, 
corretti con la funzione UPDATE (che � il prezzo da pagare per la pigrizia) */

CREATE TABLE Categoria (
CategoriaID INT,
CategoriaNome varchar(100),
CONSTRAINT PK_Categoria PRIMARY KEY (CategoriaID)
);

INSERT INTO Categoria (CategoriaID, CategoriaNome) 
VALUES
(1, 'Giocattoli'),
(2, 'Videogiochi');


CREATE TABLE Prodotti (
ProdottoID INT,
ProdottoNome varchar(100),
CategoriaID INT,
PrezzoUnitario DECIMAL(10,2),
CONSTRAINT PK_Prodotti PRIMARY KEY (ProdottoID),
CONSTRAINT FK_Prodotti_Categoria FOREIGN KEY (CategoriaID) 
REFERENCES Categoria(CategoriaID) 
);

INSERT INTO Prodotti (ProdottoID, ProdottoNome, CategoriaID, PrezzoUnitario) 
VALUES
(1, 'X-Wing', 1, 49.99),
(2, 'Dishonored 2', 2, 39.99),
(3, 'Orso Ciro', 1, 19.99),
(4, 'Nintendo Switch', 2, 349.99),
(5, 'Set Lego Minecraft', 1, 69.99);

select*
from Prodotti

CREATE TABLE RegioneArea (
RegioneAreaID INT,
RegioneAreaNome varchar(100),
CONSTRAINT PK_RegioneArea PRIMARY KEY (RegioneAreaID)
);

INSERT INTO RegioneArea (RegioneAreaID, RegioneAreaNome) VALUES
(1, 'Nord Europa'),
(2, 'Est Europa'),
(3, 'Sud Europa'),
(4, 'Ovest Europa'),
(5, 'Sud-est Europa');



CREATE TABLE Regione (
RegioneID INT,
RegioneNome varchar(100),
RegioneAreaID INT,
CONSTRAINT PK_Regione PRIMARY KEY (RegioneID),
CONSTRAINT FK_Regione_RegioneArea FOREIGN KEY (RegioneAreaID)
REFERENCES RegioneArea(RegioneAreaID)
);

select *
from Regione

INSERT INTO Regione (RegioneID, RegioneNome, RegioneAreaID)
VALUES
(101, 'Svezia', 1),
(102, 'Polonia', 2),
(103, 'Italia', 3),
(104, 'Spagna', 4),
(105, 'Grecia', 5);

UPDATE Regione
SET RegioneID = 
    CASE 
        WHEN RegioneNome = 'Svezia' THEN 1
        WHEN RegioneNome = 'Polonia' THEN 2
        WHEN RegioneNome = 'Italia' THEN 3
        WHEN RegioneNome = 'Spagna' THEN 4
        WHEN RegioneNome = 'Grecia' THEN 5
    END;

CREATE TABLE Vendite (
OrdineNumero INT,
ProdottoID INT,
RegioneID INT,
OrdineData DATE,
OrdineQuantit� INT,
PrezzoTotale DECIMAL (10,2),
CONSTRAINT PK_Vendite PRIMARY KEY (OrdineNumero),
CONSTRAINT FK_Vendite_Prodotti FOREIGN KEY (ProdottoID)
REFERENCES Prodotti(ProdottoID),
CONSTRAINT FK_Vendite_Regione FOREIGN KEY (RegioneID)
REFERENCES Regione(RegioneID)
);

INSERT INTO Vendite (OrdineNumero, ProdottoID, RegioneID, OrdineData, OrdineQuantit�, PrezzoTotale) 
VALUES
(1, 3, 3,'2023-11-15', 2, 39.98),
(2, 3, 2,'2023-12-01', 3, 59.97),
(3, 2, 3,'2023-12-10', 1, 39.99),
(4, 5, 1,'2024-01-05', 2, 139.98),
(5, 5, 2,'2024-01-20', 6, 419.94);


--Verifico l'univocit� delle chiavi primare delle tabelle--

SELECT COUNT(*), CategoriaID 
FROM Categoria
GROUP BY CategoriaID 
HAVING COUNT(*) > 1

SELECT COUNT(*), ProdottoID 
FROM Prodotti
GROUP BY ProdottoID
HAVING COUNT(*) > 1

SELECT COUNT(*), RegioneAreaID
FROM RegioneArea
GROUP BY RegioneAreaID
HAVING COUNT(*) > 1

SELECT COUNT(*), RegioneID
FROM Regione
GROUP BY RegioneID
HAVING COUNT(*) > 1

SELECT COUNT(*), OrdineNumero
FROM Vendite
GROUP BY OrdineNumero
HAVING COUNT(*) > 1


/* Esporre l�elenco delle transazioni indicando nel result set il codice documento, la data,
il nome del prodotto, la categoria del prodotto, il nome dello stato, 
il nome della regione di vendita e un campo booleano valorizzato in base alla condizione 
che siano passati pi� di 180 giorni dalla data vendita o meno (>180 -> True, <= 180 -> False) */

SELECT *
FROM Vendite

SELECT 
v.OrdineNumero,
v.OrdineData,
p.ProdottoNome,
c.CategoriaNome,
r.RegioneNome AS Stato,
ra.RegioneAreaNome AS Area,
CASE 
	WHEN DATEDIFF(DAY,v.OrdineData,GETDATE()) <= 180 THEN 'FALSE'
	ELSE 'TRUE'
END				AS MoreThan180Days,
v.PrezzoTotale

FROM Vendite	AS v 

LEFT JOIN Prodotti AS p
ON v.ProdottoID = p.ProdottoID
LEFT JOIN Categoria AS c
ON p.CategoriaID = c.CategoriaID
LEFT JOIN  Regione AS r
ON v.RegioneID = r.RegioneID
LEFT JOIN RegioneArea AS ra
ON  r.RegioneAreaID = ra.RegioneAreaID

/* 3)	Esporre l�elenco dei soli prodotti venduti e per ognuno di questi il fatturato totale per anno. */

SELECT 
p.ProdottoNome,
YEAR(v.OrdineData)		AS Anno,
SUM(v.PrezzoTotale)		AS TotaleFatturatoAnnuo
FROM VENDITE AS v
LEFT JOIN Prodotti AS p
ON v.ProdottoID = p.ProdottoID
GROUP BY p.ProdottoNome, YEAR(v.OrdineData)

/*4)	Esporre il fatturato totale per stato per anno. Ordina il risultato per data e per fatturato decrescente. */

SELECT r.RegioneNome,
YEAR(v.OrdineData) AS Anno,
SUM(v.PrezzoTotale) AS FatturatoPerAnno
FROM Vendite AS v
LEFT JOIN Regione AS r
ON v.RegioneID = r.RegioneID
GROUP BY r.RegioneNome, YEAR(v.OrdineData)
ORDER BY FatturatoPerAnno DESC

/*5)	Rispondere alla seguente domanda: qual � la categoria di articoli maggiormente richiesta dal mercato?*/
--La risposta �:--
SELECT Categoria.CategoriaNome, 
COUNT(Categoria.CategoriaNome) AS RichiestaDalMercato
FROM Vendite
LEFT JOIN Prodotti
ON Vendite.ProdottoID = Prodotti.ProdottoID
LEFT JOIN Categoria
ON Categoria.CategoriaID = Prodotti.CategoriaID
GROUP BY CategoriaNome
ORDER BY CategoriaNome

/*6)	Rispondere alla seguente domanda: quali sono, se ci sono, i prodotti invenduti? Proponi due approcci risolutivi differenti.*/

/*Approccio 1: query innestata, � possibile verificare l'esattezza con la seconda query, 
che propone lo scenario inverso*/

SELECT ProdottoNome
FROM Prodotti
WHERE ProdottoID NOT IN (SELECT ProdottoID
						FROM Vendite)
				---------------------------
SELECT ProdottoNome
FROM Prodotti
WHERE ProdottoID IN (SELECT ProdottoID
						FROM Vendite)

/*Approccio 2: Join */

SELECT Prodotti.ProdottoNome, OrdineNumero
FROM Prodotti
LEFT JOIN Vendite
ON Prodotti.ProdottoID = VENDITE.ProdottoID
WHERE Vendite.ProdottoID IS NULL

/*7)	Esporre l�elenco dei prodotti con la rispettiva ultima data di vendita (la data di vendita pi� recente).*/

SELECT p.ProdottoNome, MAX(v.OrdineData)
FROM Vendite AS v
LEFT JOIN Prodotti AS p
ON v.ProdottoID = p.ProdottoID
GROUP BY p.ProdottoNome

SELECT *
FROM Vendite

/*8) Creare una vista sui prodotti in modo tale da esporre una �versione denormalizzata� delle informazioni 
utili (codice prodotto, nome prodotto, nome categoria)*/

CREATE VIEW VW_FC_PRODUCTS AS (

SELECT 
	p.ProdottoID,
	p.ProdottoNome,
	c.CategoriaNome
FROM Prodotti AS p
LEFT JOIN Categoria AS c
ON p.CategoriaID = c.CategoriaID
)

/*9) Creare una vista per restituire una versione �denormalizzata� delle informazioni geografiche*/

CREATE VIEW VW_FC_GEOGRAPHY AS (

SELECT	r.RegioneNome, 
		ra.RegioneAreaNome,
		r.RegioneID
FROM Regione AS r
LEFT JOIN RegioneArea AS ra
ON r.RegioneAreaID = ra.RegioneAreaID
)

select *
from VW_FC_GEOGRAPHY

CREATE VIEW VW_FC_SELLS AS (

SELECT *
FROM Vendite
)